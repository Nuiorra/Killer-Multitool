# Killer Multitool
 A simple batch multitool.
